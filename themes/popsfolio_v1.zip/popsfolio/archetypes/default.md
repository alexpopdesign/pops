---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
draft: false

# seoTitle:
# description: 

# weight:
## Hide this page in lisitings
# hideInList: true

# siteHeaderInverse: true
# siteHeaderClass: bg-black inverse
# blockClass:
# background_color_HEX: ""

# links:
#  link1:
#    link: 
#    link_label:

## This link to template only if Carrd card is in content {{< carrd >}} (in top of content)
# carrdTemplateLink: https://carrd.co/dashboard/add/168671dae0c9f664

---
