---
title: "{{ replace .Name "-" " " | title }}"
seoTitle:
description: ""
date: {{ .Date }}
draft: false

link: 
link_caption: 

author: 
author_link:

tags: [decor]
---
