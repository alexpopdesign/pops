// Collapse "collapse-target" in each parent "collapse"
//<div class="collapse">
// <p class="collapse-target">

  var collapseElements = document.querySelectorAll('.collapse');
  // Get all collapse target elements
  var collapseTargets = document.querySelectorAll('.collapse-target');
  // Iterate over each collapse target element
  collapseTargets.forEach(function(collapseTarget) {
  // Find the closest parent div element to the collapse target
  var closestDiv = collapseTarget.closest('div');
  // Add the "collapse-parent" class to the closest div element
  if (closestDiv) {
    closestDiv.classList.add('collapse-parent');
  }
});
// Add click event listener to each collapse element
collapseElements.forEach(function(collapseElement) {
  collapseElement.addEventListener('click', function () {
    // Toggle the "show" class on the clicked collapse element
    this.classList.toggle('show');
  });
});